class bubblesort:
    def __init__(self, arr):
        self.arr = arr

    def bubbleSort(self, arr):
        n = len(self.arr)
        for i in range(n-1):
            swapped = False
            for j in range(0, n-i-1):
                if self.arr[j] > self.arr[j + 1]:
                    swapped = True
                    self.arr[j], self.arr[j + 1] = self.arr[j + 1], self.arr[j]

        if not swapped:
            return

